﻿Star Maker: Worms Armageddon map generator
————————————————————————————————————————————————————————————————

—| OVERVIEW

  This is interesting stuff which creates WA maps in quite unique style ^^
  Made from myself, some time ago I was playing online and often hosted my games.

—| MAIN FEATURES

  Oh, just run and see. But first see info about installation, as this program requires some things
    to do manually (yes, because I was too lazy :3) 

—| INSTALLATION & USAGE

  - first unpack program into Worms Armaggedon directory (where wa.exe is placed).
    You can unpack it anywhere, but game folder is preffered.
  - now check that folder "User\SavedLevels" exists around #Star_Maker.exe.
    It is a folder where it stores maps and this folder not recreated automatically.
  - finally Gflax_Lite.dll library should be registered (it is used to draw maps).
    Run regGflax.bat or do that manually (both cases may require admin permissions).
  
  After that, all should work fine, so just run it and generate as many maps as you want ^^
  There is no lot of options, mostly just random and random.
  Also if you using my HeavyEdit utility, StarMaker will automatically integrate into it (HeavyEdit is also a launcher).

You can also contact me For any kind of feedback.
———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

1.0.0.??
  - history is missing :/
  - as well as I once lost part of this app code. a very important part, and then was unable to reproduce it, hah
  - thus current version is different than it was (maybe worst, maybe not. hard to say)
