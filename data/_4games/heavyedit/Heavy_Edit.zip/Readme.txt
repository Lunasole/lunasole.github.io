﻿Heavy Edit: powerful Worms: Armageddon scheme editor and generator.
————————————————————————————————————————————————————————————————

* How to use:
  Hi. I'm too lazy now to write any detalized instruction here (and probably it is not needed), so USE THE FORCE
    to deal with that evil program ;)
  There's only one hint: TO MAKE IT WORK, PLACE PROGRAM RIGHT AT WORMS ARMAGEDDON DIRECTORY, WHERE WA.EXE IS LOCATED


* Features and overview:
  It can edit every variable of scheme file and set it to any value.
  Several options are checkbox-like style, others implemented as textboxes,
    where you can put any number from 0 to 255.

  It also generates randomized schemes, and there is a set of special options for this.
  No need to describe this all here, as the interface is nicely self-documented - so just check the tooltips,
    or "click and try" ^^

  The editor magic number is 0x2A


* Short story:
  Program was started at 22 july 2012, after I disliked any other scheme editors 
    and desired to make my own one, WITH RANDOM BYTES, BITS AND FREEDOM.
  The second reason was than I've got idea of fully randomized schemes for classic games,
    to play them without Rubbershit or PX or other mods, so I needed clear scheme generator with my own rules.
  You may see the result of all this now.


* How I'm using it:
  Usually I'm generating a lot of random schemes and just picking random one for every game.
  This makes every game unique and that is very cool.


* Why it looks like a program that my grandfather has used?
  The editor view is especially made "old and gray", as the Worms:Armageddon game is from 1990x :)


So, SPARTANIC, MINIMALISTIC, IT COMES HERE

If you have founded bugs, got some various questions or suggestions,
  send me a sign :3
———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

1.0.0.118
  - reviewed a bit, to post on my site

1.0.0.?
  - changelog missing