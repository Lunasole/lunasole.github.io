﻿BrickGame 3000: just how it sounds
————————————————————————————————————————————————————————————————

—| OVERVIEW

  My first "non-commercial game made with quality of commercial level".
  Or saying else: first game I've completed and it doesn't looks and plays (and built internally) like a total crap ^_^
  Though there is a lot of possible features to add, generally it is playable.


—| CONTROLS

  Player-1 in-game controls:
    - left/right:       move figure
    - down:             move figure down
    - up:               rotate figure

  Player-2 in-game controls:
    - numpad 4/6:       move figure
    - numpad 5:         move figure down
    - numpad 8:         rotate figure

  Menu controls:
    - up/down:          move selection
    - enter/space:      hit item
    - esc/backspace:    back
    - left/right:       modify selected value (options)


———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

1.0.1.8
  - improved graphics
  - fixed tricky bug with rotation
  - few more important changes (internal)
  
1.0.1.7
  - greatly raised performance (finally optimized all it a bit)
  - changed design
  - weakened difficulty for classic modes (no more such a die-young-hardcore)
  - added some extra variable to a scoring formula
  - improved input
  - improved some effects/few new effects added
  
1.0.1.6
  - changes to window message handling 
  - few other things changed

1.0.1.5
  - new game mode: 2-players, classic
  - internal improvements & cleanup

1.0.1.4
  - first "seems it's done" version