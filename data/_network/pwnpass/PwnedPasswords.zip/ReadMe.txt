﻿PwnPass: password leakage checker
————————————————————————————————————————————————————————————————

—| OVERVIEW

  This tool is a desktop version of HaveIBeenPwned service.
  It utilizes provided API to check if given password present in one of leaked datasets.
  It uses so called "k-anonymity" principle. The entered password (or it hash) never is revealed.
  Only the first 5 characters of SHA-1 hash are used to query API.
  Then list of similar hashes is returned and it is possible to find matching one.

—| MORE INFO
  The tool itself is very simplified and uses only one of many other leaks-related 
    things present by "Haveibeenpwned".
  I've made it just because it's better than download/update all available databases and
    store them locally.

  Here are some more docs about that all:
    https://haveibeenpwned.com/API/v2#PwnedPasswords
  
  And the link to main site:
    https://haveibeenpwned.com/

———————————————————————————————————————————————————
https://lunasole.github.io/
(c) Luna Sole
———————————————
[History]

1.0.0.0
  - first one