﻿MyMp3Coder: simple "anything to mp3" converter
————————————————————————————————————————————————————————————————

—| OVERVIEW

  This is remake of my old FFMPEG shell. There are so many "encoders" made
    by different authors over ffmpeg, but anyway I needed my own :)

  A simple MP3 convertor by fact - it accepts any files, and if possible,
    converts them to mp3.

  This way audio from video files etc, can be extracted, but mostly I've used it
    to recode files with lower quality (and lower disk space requirements).

  There is set of valuable options (like bitrate) and nothing more of what is needed or not :)



—| CREDITS

  ffmpeg is used to encode/decode files
    (http://ffmpeg.org/)



———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

1.0.0.0
  - first version
