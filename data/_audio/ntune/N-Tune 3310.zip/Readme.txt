﻿N-Tune 3310:   Nokia 3310 composer tracks player
————————————————————————————————————————————————————————————————
* How to use:
  - open your ringtone file with N-Tune 3310

* Ringtone file format:
  - generally, it is regular text file
  - file extension doesn't matter
  - encoding supported: ASCII / UTF8 / Unicode (read this as "doesn't matter too" ^^)
  
  The first string in file should be value
    Tempo=170
  Which defines playback tempo, like Nokia composer allows to set.
  Surely you should use your number for this instead of 170.
  The number can't be lower than 0, also it is bad idea to set extremely high or low values :3
  If this paramether doesn't specified in file, then default value is used (156)

  The following data of file are notes.
  Notes are delimited by spaces, also tabs and newlines allowed as well.
  You can find information about note format of Nokia 3310 through google,
    or check it on your phone (if you still have one ^^).
  If note is incorrect, N-Tune 3310 will show message about it.

* Where to get files
  There are lot of them on many sites - you can just copy-paste notes to text file and play it.
  Also there is one included for example.

This program was made by my friend's idea.
It can be useful to listen some ringtones before adding them to phone 
  (which is the hard work, unlike typing or copy-paste on PC).
Or just to have fun with 8-bit sound ^^

Any suggestions are welcome.
————————————————————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Lunasole
———————————————

* History *
1.0.0.18
  - tempo= now can be written with spaces around "=" sign :3
  - fixed bug causing part of note samples to "get lost", resulting in additional pause between notes

1.0.0.17
  - now window automatically closes after 2 second when playback is finished
  - few little changes

1.0.0.16
  - added tempo support

1.0.0.15
  - lot of improvements, mainly internal

1.0.0.0
  - first version