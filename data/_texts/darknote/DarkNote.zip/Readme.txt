﻿DarkNote: some daily log, encrypted notes and more
————————————————————————————————————————————————————————————————

—| OVERVIEW

  Another program for my world :3
  It is made to replace my old password manager and additionally allows
    to store some texts in a form similar to social networks "timeline" 
  (damn that's very useful sometimes and better than use .txt)


—| ENCRYPTION

  The secured part of this program is called "Notes".
  It works as passwords or other info storage.

  Every note here is separated file, all notes listed in list and
  accessed using defined password (can be different for every file).

  AES-256/CBC used for encryption. Password hashing algorithm with some customizations.
  That's half less complicated than stuff I've used in previous program,
  but anyway more than enough for you to fail with any decryption attempts without PWD..


———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

1.0.0.4
  - fixed "Refresh" function of notes menu: now it scans only files in "darknotes" directory, not including subfolders

1.0.0.3
  - valuable improvement for "darkstory": now story files are split to 32kb per file and named from "Time-001.txt" to "Time-999.txt"

1.0.0.2
  - added notes list sorting

1.0.0.1
  - added history search (use Enter and F3 to search down, F4 to search up)
  - added DPI-awareness manifest
  - various internal and UI improvements
  - fixed bug with overwrite confirmation on note saving

1.0.0.0
  - first complete version