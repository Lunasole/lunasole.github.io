﻿PCURL: A simple blocking threadsafe HTTP/S DLL for PB
————————————————————————————————————————————————————————————————

—| OVERVIEW

  I've made this when needed quicky get from somewhere multithreaded HTTP lib which allows
    raw data processing (and has no other disadvantages which PB Curl wrapper has).

  By fact this DLL is wrapper over curl headers (and they are wrapped over PB HTTP wrapper of original CURL :3)
  Fell the power of wrap!


—| MAIN FEATURES

  - GET/POST/HEAD and any other basical things (if you going to do them manually ^^)
  - proxy support
  - simple threading support (tested with 1000+ threads already)
  - raw access to received HTTP data
  - custom HTTP headers support (referer, cookies, user-agent)
  - custom request timeout support
  - maybe something else ^^



—| USAGE & CONTROLS

  It's pretty simple as there is only one function exported:
    ReceiveHTTP()
  See GetExample.pb for details and ready-to-use code.

  For multithreading: generally you load library and importing function in main thread, then create 
    lot of threads in your app, and then calling library function safely from them.
  That's of course not exactly how "asynchronous sockets" meant to be, but is enough for 90% of network client software.

  Finally, if you want something else or made another way, go and edit "PCURL.pb"/"libcurl.pbi" files 
    (or write me, because I'm often too lazy to add some extra stuff without requests :3)


—| CREDITS

  Thanks a lot to @infratec for original "libcurl.pbi"

———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

1.0.0.40
  - added support of binary content downloading (not only HTML text as it was previously)
  - additional argument to disable HTTP responce headers
  - removed that "dirty http parsing code" from example, it really should not be used ^^
  - other various code changes/reviews

1.0.0.38
  - fixed proxy issue (it was simply not working ^^)
  - fixed another stupid mistake with custom headers
  - added automatical redirects on 302, etc (hardcoded in PCURL.pb)
  - added links to a curl docs explaining features DLL supports (see comments in both sources)
  - several other minor things

1.0.0.37
  - 1st public build
