﻿ADBAppTools: ADB (Android Debug Bridge) GUI tool
————————————————————————————————————————————————————————————————

—| OVERVIEW
  This tool uses ADB command shell to operate.
  I've made it to simplify some things which may be done using ADB:
    - app management (deleting/disabling, etc)
    - device config management
    - displaying different info
  Rooting of device is not needed.

—| SETUP & USAGE
  
  1) Install ADB (https://developer.android.com/studio/command-line/adb)
  2) Place this program executable to the same directory where ADB.exe is installed.
  3) Enable debugging over USB at your android device
  4) Connect device to PC using USB, and confirm debugging.
  5) Use "Reload" command to connect to the device and init

———————————————————————————————————————————————————
https://lunasole.github.io
(c) Luna Sole
———————————————
[History]

1.0.0.0
  - first version
  - "Write config" and "Dump" commands are not working yet