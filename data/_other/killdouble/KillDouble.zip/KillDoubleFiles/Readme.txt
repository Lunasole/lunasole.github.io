﻿KillDoubleFiles: delete file duplicates in specified folder 
                  and it's subfolders
————————————————————————————————————————————————————————————————

* How to use:
  - drag&drop folder to executable, or use command line

USE WITH CARE, it doesn't move files to recycle before deleting.
———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

1.0.0.45
  - first and final version

