﻿KillDoubleStrings: removes string duplicates in specified file
————————————————————————————————————————————————————————————————

* How to use:
  - just drag&drop files to executable, or use command line

———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

1.0.0.45
  - first and final version

