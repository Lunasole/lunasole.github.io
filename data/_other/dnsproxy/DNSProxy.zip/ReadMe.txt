﻿DNSProxy: a program to monitor/affect system DNS service activity 
————————————————————————————————————————————————————————————————

—| OVERWIEW
  
  This program works as local DNS proxy, which intercepts DNS request made
    by running programs through Windows DNS service.
  It can log requests (to file and UI), also resolves them using Google DNS and
    sends results back to a programs.
  This can be changed to filter domain names for example, which can be used to 
    control web on current machine/restrict access to some or most sites, etc.
  See about filter.dll


—| INSTALL/CONFIGURE

  For now it's complicated and performed manually :3
  
  1) Configure firewall:
    - allow DNSProxy.exe outbound connections to IP 8.8.8.8, port 53 (which is google DNS)
    - allow DNSProxy.exe inbound connections to port 53 from localhost (here it accepts request made through system DNS service)
    - allow svchost.exe process to connect 127.0.0.1:53
    All connections meant to be UDP + IPv4, IPv6 currently is not supported.

  2) Configure network connection:
    - set your connection primary DNS server address to 127.0.0.1 (localhost)  
    TIP: You can set secondary address to real DNS server, then it will be used when DNSProxy.exe is not running
          and you don't need to change primary everytime.

  3) Finally run program and see if something goes on
    If all OK, you will se DNS activity log when using browser/other network programs


—| FILTER.DLL
  
  This is like a simple plugin, which allows to perform actions over domain names processed by DNSProxy.
  For now domains may only be blocked this way.
  The DLL sources are in FilterDLL.pb file, you can build it if needed.
  Also see sources for details.

  Important about blocking: it will work only if Windows has no DNS servers in list, except primary set to
    DNSProxy. Else it will just ask secondary servers when DNSProxy won't resolve.


—| LOG AND UI

  Program log is displayed on UI and written to file (log.log)
    - "Q" marks DNS requests received from local programs and OS 
    - "A" means responces from Google DNS sent back to programs
    - [FFFF] identifies query ID (defined by program which sent request)


———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

1.0.0.2
  - fixed init code 
  - added support of Filter.dll (for now it allows to block domain resolving, see details in readme)

1.0.0.1
  - fixed crashes caused by incorrect connections handling
  - added exception handler
  - added log autoscrolling

1.0.0.0
  - first test version
