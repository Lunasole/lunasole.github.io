CMDInterceptor: does how it sounds
————————————————————————————————————————————————————————————————

—| OVERVIEW

  This is kind of simplest utility which only shows command line arguments it receives.
  Useful sometime to steal those arguments from other processes (replacing them with a copy of this utility).
  Like you can replace compiler with it, and see it's raw commandline.

———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

1.0.0.1
  - now parent process name is displayed

1.0.0.0
  - first version