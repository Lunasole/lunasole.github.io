﻿YourAngel by Lunasole
What it does? Draws semi-transparent text on your desktop.
  - hold LCTRL and click text to move it
