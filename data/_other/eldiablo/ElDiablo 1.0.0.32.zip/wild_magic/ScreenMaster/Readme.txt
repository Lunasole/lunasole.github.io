﻿ScreenMaster by Lunasole
What it does? Automatically controls screensaver.
  - if you move mouse cursor right to the top of the screen and leave untouched, screensaver will be launched within several seconds
  - in all other cases screensaver will not launch
  - on unload screensaver will remain disabled
