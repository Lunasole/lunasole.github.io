﻿RecycleFlow42 by Lunasole
What it does? Automatically deletes files older than 42 days from recycler.
