﻿PasteLogg by Lunasole
What it does? Captures text from clipboard to text file.
	- hit CTRL+C twice to capture current text
