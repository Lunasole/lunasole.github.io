﻿KeyDiag: simple keyboard monitor
————————————————————————————————————————————————————————————————

—| OVERVIEW

  Small console program which monitors pressed keyboard keys.
  Originaly I've made it for some "keyboard diagnostics" (hah, that was needed after I spilled coffee over KB...)
  Also might be useful to get key code/VK constant.

———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

1.0.0.0
  - done