﻿Color Inspectre: +1 color picker for Windows
————————————————————————————————————————————————————————————————

—| OVERVIEW

  Color Inspectre is GUI-based color picker, which additionaly shows the name 
    of picked color, as well as offers some other nice features.
  I did it first of all for myself, but then also decided to make it public.

  It should be useful if you doing things like web-design 
    or just playing with image editors, etc.


—| MAIN FEATURES

  - simple and easy-to-use UI
  - interactive color picking from any pixel of your desktop
  - zoomed-in preview on color picking
  - 6 palettes to provide so much color options
  - can show selected color name and search for similar colors

  Supported color string formats:
    - HTML/CSS hex
    - C hex
    - Purebasic hex
    - Visual Basic hex
    - RGB int


—| COLOR OPERATIONS

  Picking color is pretty simple - just start capturing screen by 
    clicking-and-holding main selector control.

  After capturing color, you can copy it's value (represented in one of
    formats supported by ColorInspector), or modify it like following:

    1. Edit raw color value manually [not yet implemented]
    3. Choose another color variation from available palettes

  There are 6 palettes available at main program UI:

    1. Captured area palette. It contains zoomed area captured by selector.
    2. Auto-generated palette. This palette is built from captured image
        using special algorithm, it represent most-used colors.
    3. Similar colors list. A list of colors which are close to selected one.
    4. History palette. It stores all resently picked colors.
    5. Actual color palette. Represents current color and provides
        access to default color selection dialog.
    6. Slider palette. It allows to adjust R-G-B color components separately,
      providing live preview of changes.

  Any color from any palette can be picked by single LMB-click or click&move.


—| CONTROLS & GUI

  The program UI itself has tooltips displayed on mouse-over to ease learning.
 
  You can toggle UI size to hide/show similar colors list:
    - perform a RMB-click at area near options button

  There are ways to make capture more easy and accurate.
  While using selector or palette:
    - hold CTRL key, to slow mouse cursor a lot
    - press arrow keys, to move cursor by 1px

  This may be especially useful on high-resolution displays
    or if your mouse has too many DPI :)


—| CREDITS

  This software is inspired by "ColorCop" utility:
    http://colorcop.net/
    (c) 1999-2007, Jay Prall.
  That's the best color picker I ever seen :3

  Also, thanks @Tristano for expanded color names table, which I took 
    from his "NameThatColor" utility:
    https://github.com/tajmone/name-that-color 
    (originally from Chirag Mehta’s code).


———————————————————————————————————————————————————
http://lunasole.github.io/
(c) Luna Sole
———————————————
[History]

1.0.0.7
  - small fixes and homepage link updated

1.0.0.6
  - fixed minor bug with slider palette controls (text values were empty on program start if component value = 0)
  - improvements to capture palette
  - redesigned UI + other changes

1.0.0.5
  - added some raw values editing (at last): edit R-G-B components using slider palette
  - fixed bug with collor selector on non-standart DPI settings
  - dropped out that help window and used good old "readme.txt" instead ^^

1.0.0.4
  - some more DPI-scaling related fixes

1.0.0.3
  - added slider palette (#6), thanks to Alex Khasmamedov for idea
  - several UI changes and redesign
  - preventing that stupid DPI scaling
  - added minimize button (why it was missing previously?)
  - now mouse slowdown by CTRL and arrow keys supported in all palettes
  - improved window positioning on start
  - improved "about program" functional
  - fixed positioning of options menu
  - fixed bug with history/auto/capture palettes 
    (color was not picking on single click)
  - raw values editing still not implemented :3

1.0.0.2
  - so MUCH MORE functions added (almost all which were planned ^^)

1.0.0.1
  - lot of planned functionality added

1.0.0.0
  - first operational version
