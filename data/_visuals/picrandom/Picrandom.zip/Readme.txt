﻿PicRandom:    minimalistic picture viewer
                with randomizing and specific picture sorting alibities
————————————————————————————————————————————————————————————————

* HOWTO:
  You can use PicRandom one of following ways:
    - put copy of PicRandom.exe to a folder with your images and run
    - open PicRandom.exe with specifying folder path as program parameter
    - run PicRandom.exe and Drag&Drop folder with images to it's window

  After this given folder and it's subfolders are searhed for images (or previous index used) and the show begins.
  PicRandom generates file with .dat extension at given folder - that's index of files.
  It is used to store view session. You can safely delete this file when it is not needed.
  This index has to be rebuilded if you updated folder with images - use "Rebuild List" to do that.
  Also it is rebuilded when .dat file has been deleted.


* FUNCTIONALITY:
  The meaning of this program is ability to watch pictures in random order.
  Also it allows quickly review pictures and delete ones you don't like or
    move to "stasis" ones you like much more :)
  See "Controls" section for details.

  Some features:
    - 2 modes: manual and slideshow with specified interval
    - pictures are not repeating until all of them viewed or Reset performed
    - auto resample with original aspect ratio
    - settings stored in registry, so you can easily copy executable to a lot of folders
    - nothing additional to bloat program

  Following image types supported:
    .bmp.jpg.jpeg.jpe.gif.ico.ani.cur.png.tga


* CONTROLS:
  Manual mode controls:
    - RMB anywhere          - popup menu
    - LMB anywhere          - next random file
    - Space                 - next random file
    - Delete                - move current file to Recycle
    - Down arrow            - move current file to Recycle
    - Up arrow              - move file to a special folder: "stasis"
    - Left arrow            - previous file (left from current)
    - Right arrow           - next file (right from current)
    - Return                - toggle fullscreen mode
    - M                     - hide program window
    - Escape                - close & save session index

  Slideshow controls:
    - RMB anywhere          - popup menu
    - Delete                - move current file to Recycle
    - Down arrow            - move current file to Recycle
    - Up arrow              - move file to a special folder: "stasis"
    - Return                - toggle fullscreen mode
    - M                     - hide program window
    - Escape                - close & save session index


* POPUP MENU OVERVIEW:
  #Goto ...                 - show file from current list using it's number

  More > Shell File         - opens file in your default image viewer
  More > Shell Folder       - opens folder of current file
  More > Shell Root Folder  - opens folder of current session

  Copy to \stasis_back...   - copy current file to a "___stasis_back" folder
  Move to \stasis...        - move current file to a "___stasis" folder
  Move to recycle...        - delete current file and remove it from session index

  Reset Viewer              - reset current session state and start it again
  Rebuild List...           - clear session index and rebuild it

  Close & erase list...     - close program and delete session index file
  Close                     - close program and save session index file


* THE "STASIS" FOLDER:
  This is a special folder, created automatically in a root folder of current session.
  It's name is "__stasis" and it is not indexed by Pic Random.
  The aim of this folder is to move pictures "highlighted" by user here.

  There also is a "__stasis_back" folder. It's purpose is the same, but
    unlike "Stasis" pictures are not deleted after moving to it.
  So it is a special folder to store copies of "highlighted" pictures here.


* KNOWN PROBLEMS:
  It doesn't support unicode in folder/file paths. That's limitation of VB6.
  I don't see reason to fix this, as unicode chars used in paths are rare case for me ^^


* THANKS & CREDITS:
  - to XNVIEW for GFlax library


———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

1.0.0.129
  - first and final version
