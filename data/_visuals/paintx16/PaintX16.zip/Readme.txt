﻿PaintX16: vector drawing stuff
————————————————————————————————————————————————————————————————



—| OVERVIEW

  This is minimalistic vector editor, created as "a side product" of stuff I've needed for another stuff ^^
  I liked results so much that spend some time to make standalone program from it.
  Though It is far from truly usable vector editor, sometimes it may be useful.


—| MAIN FEATURES

  It is simple, easy to use, also has feature you may consider strange - only 16x16 canvas is used for drawing.
  
  What about other features, it act like any other editor:
  - drawing, editing
  - export results to PNG
  - save/load raw data using custom format

  And so on, better go and try instead of expecting 1Kb words here :3
  

—| USAGE & CONTROLS
  
  Keyboard shortcuts and similar useful info:

    [In draw mode]
      1         :   set initial coordinates to current mouse position
      2, 3      :   depends on tool, try it yourself
      ESC       :   cancel drawing
      +, -      :   adjust draw width
      M         :   switch draw method
      V         :   switch draw mode
      W, S      :   modifies alpha channel/transparency

    [Generic]
      Num4, Num6:   adjust canvas width
      Num2, Num8:   adjust height

    [Items list]
      Mouse     :   drag&drop to reorder items
      LMB       :   select items and toggle items visibility. use combinations with Ctrl and Shift to select multiple items
      RMB       :   context menu

    [Selected items processing]
      Arrows    :   changes selected items position (if none selected, all items are moved)
      A, D      :   rotate selected items
      Delete    :   delete selected
      +, -      :   redefine draw width
      M         :   redefine draw method
      V         :   redefine draw mode
      W, S      :   redefine alpha channel/transparency of selected items
      Space     :   redefine items color to current color



———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

1.0.0.4
  - added new param: drawing mode (corners rounding, etc)
  - now canvas can be resized (thus not always x16 ^^)
  - now palette is saved to config

1.0.0.3
  - nice improvements to all that X16 concept
  - added config and much more for usability
  - added misc useful things
  - several internal code improvements

1.0.0.2
  - some more improvements :3 but anyway there are much more things to do sometime later

1.0.0.1
  - many things improved

1.0.0.0
  - first version