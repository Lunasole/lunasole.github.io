﻿CodeAngel:  a tool for PB IDE to backup whole projects or 
              single files
————————————————————————————————————————————————————————————————

* Features:
  - backup whole project or only it's code and text files
  - backup single file with source code

  By fact, it is some simplest SVN. I think it is much more usable than existing PB session database.
  All interaction with program is simple and most of the stuff performed automatically.


* Attaching CodeAngel to Purebasic IDE:
  There are 3 options to run CodeAngel with.
    And here are instructions to add them all.

    First one used to back up current project (only it's code and text files, lite version of backup):
      1. Add IDE tool with name "CodeAngel [project]"
      2. Set 'Arguments' exactly to /P "%PROJECT" /W "%WORD"
      3. Set 'trigger' to Menu Or Shortcut
      4. Finally, set 'CommandLine' to a path of CodeAngel.exe

    The second is the same, but it packs ALL files from project folders:
      1. Add IDE tool with name "CodeAngel [project, /all]"
      2. Set 'Arguments' exactly to /P "%PROJECT" /W "%WORD" /ALL
      3. Set 'trigger' to Menu Or Shortcut
      4. Finally, set 'CommandLine' to a path of CodeAngel.exe

    And last one is used to backup only currently active file:
      1. Add IDE tool with name "CodeAngel [ file ]"
      2. Set 'Arguments' exactly to /F "%FILE"
      3. Set 'trigger' to Menu Or Shortcut
      4. Finally, set 'CommandLine' to a path of CodeAngel.exe

    It's of course not nice to add this all manually, but currently no other way ^^


* Some notes:
  When doing project backup, the program takes project file (.pbp)
    and looks all the files of it's folder and subfolders.
    So keep in mind that any external files placed higher in filesystem than
    project file, are NOT backed up.

That's should be all that should be said Here ^^
For any kind of feedback just launch e-mail to me or post to PB forum.
———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

2.0.0.0
  - first standalone version, detached from proprietary shit
