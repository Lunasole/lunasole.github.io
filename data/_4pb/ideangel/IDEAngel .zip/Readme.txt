﻿IDEAngel: tool to auto-backup PB IDE preferences
————————————————————————————————————————————————————————————————


—| OVERVIEW

  Have you ever lost your IDE config? Or your precious code templates?
  If "no", using this stuff might save you one day.
  If "yes", you probably already have more reasons to use it or something similar ^^ (like me)



—| INSTALLING

  The tool must be launched from PB IDE, because it uses environment variable to determine prefs folder path.
    (it does nothing if launched from outside)

  So, best option is to install it as IDE Tool with "Editor Startup" or "Editor Closing" trigger.
  No commandline params required.

  Also, the "Menu/Shortcut" trigger goes fine too (to run tool manually), but makes no much sense
    due to 7-days limit (see next section).



—| HOW IT WORKS

  - all files in PB config folder with .prefs extension are backed up
  - backup is performed once per 7 days (or 7+, it depends on how soon tool is launched after 7 days delay)
  - all the backups are stored in tool folder ("_backups" subfolder)
  - 7z archives used as storage, each archive within "_backups" is named like "prefs (DATE).7z"

  I guess backups with 7+ days interval (i.e. ~48 times per year) are optimal for prefs/templates.
  But if you have better number, tell ^^



—| RESTORING FROM BACKUP

  For now program doesn't provide any option or UI to restore semi-automatically.
  You have to do that manually in a way like this:

    0) Close PB IDE
    1) Unpack archive you need
    2) Find where PB prefs are located:
      - typically it is folder like "user_profile_folder\AppData\Roaming\PureBasic" (Windows7)
      - if IDE used in portable mode, prefs are located in IDE folder
    3) Replace existing prefs with those extracted from archive
    4) Should be fine, now can run IDE with restored prefs


———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

1.0.0.0
  - first version