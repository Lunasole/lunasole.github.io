﻿XML Structure Generator: XML parsing util
————————————————————————————————————————————————————————————————

—| OVERVIEW
  A simple UI tool which generates PB structure declares from
    input XML.

—| USAGE
  There are 3 ways to set input:
    - copy your XML text and paste to a "source" field
    - drag XML file to that field
    - open file using "Open" button
  After that, if processing was OK, result is shown immediately.

———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

1.0.0.7
  - some new version with XML parsing coded much better

1.0.0.nevermind
  - few dirty made versions