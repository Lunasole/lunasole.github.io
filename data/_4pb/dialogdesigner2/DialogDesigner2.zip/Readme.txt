﻿DialogDesigner2: dialog composer for PB dialog library

————————————————————————————————————————————————————————————————

—| OVERVIEW

  The purpose of this tool is an ability to quickly and easily form GUIs for your yet-another-cool-program.
  With DD2 it should be MUCH better than writing dialogs XML manually.


—| WHY "DIALOGDESIGNER2" INSTEAD OF "DIALOGDESIGNER"?

  That's because in the beginning (and long time ago) I was playing with another thing related to
    GUI composing. It was much more complicated (used custom rendering, and so on), also had very
    different concept and architecture.

  But when I've tried to use that old code with lot of new ideas etc, it all became too complex and
    would take too much time & effort to finish. I didn't liked to play so long with UI designer,
    so finally just used some parts of old code to design a tool much simpler and targeted on Dialog 
    library only, then called it "DialogDesigner2".


—| USAGE & CONTROLS

  All the UI is divided to a 3 parts:
    1) Main window 
      It contains preview of result and all other windows.

    2) Interface Tree window: here new items are added, deleted, renamed, etc.
      Interactions here are possible in following ways:
        1) Context menu (raised by RMB)
        2) Drag&Drop
        3) Keyboard shortcuts (as shown in menu)

    3) Properties window
      Here selected item properties are edited.

  So...
    - launch program (it is good idea to add it as PB IDE tool)
    - add items to "interface tree"
    - edit their properties/preview results
    - export results to a file

  That all should be simple enough, so nothing to add more.
  Except maybe this hint: in a "New" menu there is symbol "1"/"2" in some items, that means the
    item is container which can have specified amount of nested items.


—| CREDITS

  All this is based on Purebasic "Dialog" library and of course PB itself.
  What can I say... That library looks really nice (and also PB is really nice ^_^)


———————————————————————————————————————————————————
https://lunasole.github.io/
(c) Luna Sole
———————————————
[History]

1.0.1.7
  - Fixed XML error when reading broken config file (config routine is outdated anyway)
  - Added "margin" param for windows
  - Changed icons theme
  - Some code review (oh yes that old code really was and still remains far too messy, as it always was just a quick tool, but sometimes I'm changing something^^)

1.0.1.6
  - Output: new mode of callbacks generation (generated code)
  - Output: custom callbacks may be defined; same callback can bind to several controls if set (generated code)
  - Output: now sorting items within InitDialogs() (generated code)
  - Options: removed "add <this> variable to callback"
  - Same timestamp naming (like with XML export) added to code export
  - Yet another small change related to last.dir :)
  
1.0.1.5
  - Fixed IMA caused sometimes by tree drag&drop
  - Added hyperlink leftclick event
  - A bit changed exported code
  - Now saving XML files uses unique names (timestamp)
  - Saving code doesn't store path in config
  - Minor UI&design changes
  - Going "proprietary" again :)
    
1.0.1.4
  - Unlocked XML import feature (in less than two years!1)
  - Now XML/Code export paths using same variable in cfg
  - Storing full paths in cfg leaded to annoying behavior on import/export, now it should be simpler
  - Few internal changes and some more changes to menu labels
  
1.0.1.3
  - Added live preview of Fonts/Colors/Tooltips
  - Fixed bug with variable declarations on code export
  - Added option to not include event loop
  
1.0.1.2
  - Unlocked ID property (only numbers supported for now, not runtime constants)
  - Removed Scintilla attributes (events, variable, etc). Anyway they are not working still
  - Few minor fixes and improvements (code and XML export, also code/xml file paths are now stored in config)
  - Few internal changes/improvements
  
1.0.1.1
  - Fixed crash on XML clipboard export
  - Internal improvements / UI strings changes

1.0.1.0
  - Global: reviewed UI code a bit, some things more optimized/made simpler now (maybe it fixes something, maybe brings new problems :3)
  - Property Editor: added missing 'disabled'/'invisible' properties for image, hyperlink, ipaddress, frame, listicon, listview
  - Property Editor: added font attribute for objects supporting it. Also added font property for "dialogs" item, to set default font for all windows/controls
  - Property Editor: now properties using selector (i.e. font, fore/back colors) can be set to empty using RMB click
  - Interface Tree: added menu items to fold/unfold current item and all it's childs
  - Interface Tree: removed wrong delete confirmation displayed on "Cut" (yes, cut = copy + delete ^^)
  - Output: removed trash (extra ReleaseDC call in 'DPI patch') among with other changes to code generation
  - Some other changes (visible or not)

1.0.0.9
  - Global: optimizations, speeded it up and decreased program size
  - Property Editor: added fore/back color properties for items supporting them
  - Preview: now DPI patch changes are applied to preview window
  - Interface Tree: fixed bug with renaming (rename 'window' to 'Window' was not working)
  - Options: confirmation on item delete
  - Output: minor fixes/changes
  
1.0.0.8 - unforseen
  - Global: slowed down DD2 and raised CPU/memory usage, because of following changes and lack of optimization within them :3
  - Property Editor: added missing 'text' attribute for Editor/RTF control
  - Output: added XML patching for DPI-awareness (hah, nothing especial..)
  - Output: greatly changed code generation, added variables for windows/controls.. now it all should be more usable out-of-box :3
  - Output: greatly extended filtering to reduce amount of trash in XML/code XML
  - Output: added events for TreeList control
  - Output: other minor changes
  - Options: ability to run code file after generation
  
1.0.0.7
  - Global: added notification about unsaved changes (optional)
  - Property Editor: added tooltip attribute (using custom dd2tooltip attribute in XMl + GadgetToolTip() in code)
  - Output: added/improved events for Panel, Container, ScrollArea
  - Interface Tree: added menu option to refresh/redraw stuff manually (not sure how much point of it, but let it be :3)
  - Interface Tree: fixed item selection bug (experienced sometime on copy-paste and other actions)
  - Preview: fixed rare secondary minor and small bug with positioning
  - Options: 'this' variable now is optional (as it should be from the moment it was added^^)
  - Options: empty control text by default
  
1.0.0.6
  - Output: greatly changed events handling code (now it used 'native' event binding, instead of xml-defined)
      surely that bloats resulting code, but also:
        - bypasses PB bugs with canvas/other controls
        - removes runtime procedures/library
        - generally is "more flexible" ^^
      no more OnEvent attribute in exported code XML, while special "dd2events" attribute used on raw XML export (ignored by dialogs library as invalid)
  - Output: now every event handler has local variable "this"
  - Output: fixed missing window declares in cases when no UI callbacks generated
  
1.0.0.5 - json BM :)
  - Property Editor: removed #PB_Window_NoGadgets flag from window object (as it still acts like landmine and often causes crash even in PB 5.60)
  - added program config file (currently it has whole 1 setting)
  - Interface Tree: some changes in menu
  - Output: added "Default" case for events handling to track unhandled event types
  - Output: ability to redirect all export to clipboard (set with this 1 config setting)
  - many internal/code improvements/"refactoring" (hope without breaking something ^_^)
  
1.0.0.4
  - Output: moved dialog variables to events group (that's some more usable with functions like DialogGadget, used in callbacks)
  - Output: removed many of predefined property values (well, that was the simplest way to decrease amount of trash in resulting XML ^_^)
  - Output: added tab indentations for events
  - Output: added extended event handling
  - Interface Tree: added "Cut" action ("in less than two years")
  - Interface Tree: added keyboard shortcuts for most actions
  
1.0.0.3
  - UI: fixed issue with font size on DPI scaling (thanks Cyllceaux for pointing it)

1.0.0.2 - UI of wooden crates
  - Interface Tree: now new item is added to the end of childs list (which is not so stupid as add it was to beginning ^^)
  - Interface Tree: changed behavior caused non-empty container item become expanded on items drag'n'drop reordering
  - Output: fixed issue with encoding on code export (UTF8 BOM was missing from result file)

1.0.0.1
  - UI: program windows are now DPI-aware
  - Property editor: added support for negative integer values
  - improved output code + added cleanup
  - something else changed (nevermind)

1.0.0.0 - nice stuff
  - Interface Tree: added copy & paste functions
  - Interface Tree: added keyboard shortcut (delete)
  - Interface Tree: improved logic of drag'n'drop reorder ^_^
  - Property editor: added "text" property for a frame object
  - Property editor: added "item:" value support for "expand/rowexpand/colexpand" properties
  - Property editor: improved properties sort order
  - Property editor: now properties have correct tab order
  - Main window: improved tool windows positioning on resize
  - Main window: dialog preview now position changed
  - Output: changed code generation to bypass 8192-chars string literal limit
  - Output: several other changes
  - ... and several more things adjusted/optimized internally

0.0.0.11
  - fixes&improvements to drag&drop... again :)

0.0.0.10 - few fixes more
  - optimized interface tree menu logic
  - fixed issue with resizing of dialog preview / nicely improved that preview
  - fixed small bug with property editor / reviewed code / improved tooltips

0.0.0.9
  - fixed misstype in drag&drop handler (that was causing it not to work on WinXP, while working on Win7)
  - several UI changes
  - improved drag&drop logic

0.0.0.8 - now even more 'windows-only'
  - Interface Tree: added support of items move/sort (all this is done using "drag&drop")
  - Interface Tree: added list icons also ^_^
  - Interface Tree: improved menu
  - fixed bug with event callbacks generation

0.0.0.7 - also "alphabetawhatever"
  - removed item names limits (they were always lowercase previously)
  - now item names are filtered (no spec chars allowed for objects which have events support)
  - added all specific properties missing before: option: "group"; scrollarea: "scrolling,innerheight,innerwidth,step"; scrollbar: "page", splitter: "firstmin,secondmin";
  - added some another option to export code (with some init code, instead of embedded xml only)
  - fixed stupid bug with tree (in some condition it was causing infinite loop or crash)
  - removed those fake x-buttons from tool windows :)
  - few internal improvements of property editing window
  - improved tooltips of property editing window
  - little-but-nice improvements of preview window

0.0.0.6 - alphabetawhatever
  - first version