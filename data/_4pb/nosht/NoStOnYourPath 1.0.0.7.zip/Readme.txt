﻿When using PB OnError library, it appends full paths into resulting executables, which is not good.
Use this stuff to remove those paths.
————————————————————————————————————————————————————————————————
Installation:

  0) Compile Tool from it's sources and place where you like
  1) Goto "Tools > Configure Tools" at PB IDE menu
  2) Add new Tool
  3) Specify file path to this program executable, also give some name
  4) Set up "After Create Executable" trigger, and switch "Hide Tool from the Main menu" option
  5) Done

Now if you compile something with OnError support enabled (and without debugger),
  your resulting executable will be scanned for full paths
  with further removal of them (replaced with file name,
  i.e. "C:\UserVasya\something.pb" will be replaced to "something.pb").

———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————

[History]

1.0.0.7
  - fixed bug (search loop was stopping after founding first path, thus other paths leaved untouched)

1.0.0.6
  - code improvements
  - added message warning if reading of exe bytes fails

1.0.0.5
  - first version