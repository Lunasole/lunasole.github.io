﻿LibPCURL: yet-another-libcurl binaries (Windows)
————————————————————————————————————————————————————————————————

—| OVERVIEW

  It is a curl compiled with a 3-party SSL backend.
  Suitable for HTTPS mostly (because many other protocols dropped out here to reduce size).
  TLS/SSL of older versions also not supported (1.2, 1.3 should be good).

—| USAGE & CONTROLS

  It's not easy anymore :)
  As the usage here is equal to using raw curl.
  Some example code included anyway.

—| NOTES
  
  1) "libcurl.pbi" bindings here are outdated as for this curl version, but still
    enough for many basic things.

  2) Unlike previous versions, this one won't link as a static lib (DLL only).

—| CREDITS

  Thanks to @infratec for original "libcurl.pbi"
  See included components licenses for proper use.

———————————————————————————————————————————————————
https://lunasole.github.io/
(c) Luna Sole
———————————————
[History]

2.0.0.0
  - now it is just raw libcurl, instead of previous dirty playfoolness :)

1.0.0.40
  - added support of binary content downloading (not only HTML text as it was previously)
  - additional argument to disable HTTP responce headers
  - removed that "dirty http parsing code" from example, it really should not be used ^^
  - other various code changes/reviews

1.0.0.38
  - fixed proxy issue (it was simply not working ^^)
  - fixed another stupid mistake with custom headers
  - added automatical redirects on 302, etc (hardcoded in PCURL.pb)
  - added links to a curl docs explaining features DLL supports (see comments in both sources)
  - several other minor things

1.0.0.37
  - 1st public build
