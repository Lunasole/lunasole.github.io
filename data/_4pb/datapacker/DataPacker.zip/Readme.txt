DataPacker: one more tool for PB
————————————————————————————————————————————————————————————————

—| OVERVIEW

  It takes any file(s) and packs them to DataSection.
  Probably more detailed description is not needed :)
  

—| USAGE & CONTROLS
  
  Just Drag&Drop files or folders to a program window,
    and received output.
  Also it's better to be reasonable with file sizes.


———————————————————————————————————————————————————
http://geocities.ws/lunasole/
(c) Luna Sole
———————————————
[History]

1.0.0.2
  - now resulting data is split to several lines (reducing IDE lags on large files)

1.0.0.1
  - fixed bug with "remove selected" menu
  - fixed processing of 0-len files
  - now records of resulting DataSection are sorted
  - now records have timestamp (file modified date)
  - improved processing at all

1.0.0.0
  - first version